// This file determines the base path for the application
// For GitHub Pages, you would want to set this to the repository name
// For example, if your repo is at github.com/username/repo-name
// then your basePath would be '/repo-name'

export const basePath = '/tlc-counselling';

// When deploying to GitHub Pages, change this to your repository name
// e.g., export const basePath = '/your-repo-name';